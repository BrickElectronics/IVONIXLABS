"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { useState, useEffect } from "react"

const projects = [
  {
    title: "Robonixkart Ecom Store",
    description: "Arduino and electronics component store with fast shipping and quality parts.",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.25.43-so9cyFZC3lWj5yN1GhBIGAB7oXptsW.png",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.25.54-N11IWaCmvLchyVKY4O3tcwUGC3N4ih.png",
    ],
    link: "https://robonixkart.com/",
  },
  {
    title: "goodbye, calypso — Musical Chatroom",
    description: "An immersive music platform and live chatroom experience.",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.20.30-4hJXxY3Jq5lVMlgjTzHHf6wc67B5XZ.png",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.19.53-eQGMRR4lXFG7k9OPL0xdoAKWebMdKS.png",
    ],
    link: "https://www.adioscalypso.com/",
  },
  {
    title: "Chetana AI — Driver Monitoring",
    description: "Real‑time driver drowsiness and performance monitoring with alerting and analytics.",
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.23.30-AEl3QlWxt1k7fVUDY5mr44syqswKqX.png",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-12%20at%2016.23.53-nUesbUf7uOJaREKwnWC9sW9oWiWhQs.png",
    ],
  },
  {
    title: "AltInvest Platform",
    description: "Decentralized investment platform with multi‑chain operability.",
    images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-1vpHZj6RUc2v5pSYdjVbzKZ0NKwlB2.png"],
  },
]

export default function OurWork() {
  const [carouselIndex, setCarouselIndex] = useState<Record<number, number>>({})

  useEffect(() => {
    // Auto-rotate each project's images every 3s (only if multiple images exist)
    const timers = projects.map((proj, i) => {
      const len = proj.images?.length || 0
      if (len > 1) {
        return setInterval(() => {
          setCarouselIndex((prev) => ({
            ...prev,
            [i]: ((prev[i] ?? 0) + 1) % len,
          }))
        }, 3000)
      }
      return null
    })
    return () => {
      timers.forEach((t) => t && clearInterval(t))
    }
  }, [])

  return (
    <section id="our-work" className="py-24 px-4 bg-black">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="text-yellow-500">Innovative Work</span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Explore some of our recent projects that showcase our expertise in electronics, software engineering, AI,
            and 3D printing.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4 md:px-0">
          {projects.map((project, index) => {
            const imgs = project.images || []
            const len = imgs.length
            const current = carouselIndex[index] ?? 0

            const goto = (next: number) => {
              if (len <= 1) return
              setCarouselIndex((prev) => ({
                ...prev,
                [index]: (next + len) % len,
              }))
            }

            return (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-gray-900 overflow-hidden border border-gray-800 shadow-lg rounded-md"
              >
                {/* Image area (fit without zoom) */}
                <div className="relative aspect-[16/9] bg-black">
                  <Image
                    src={imgs[current] || "/placeholder.svg"}
                    alt={`${project.title} screenshot ${current + 1}`}
                    fill
                    // Fit image inside, no zoom/crop
                    className="object-contain"
                    priority={index < 2}
                  />

                  {/* Navigation controls for multiple images */}
                  {len > 1 && (
                    <>
                      <button
                        type="button"
                        aria-label="Previous image"
                        onClick={() => goto(current - 1)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-black/50 text-white hover:bg-black/70 flex items-center justify-center"
                      >
                        {"<"}
                      </button>
                      <button
                        type="button"
                        aria-label="Next image"
                        onClick={() => goto(current + 1)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-black/50 text-white hover:bg-black/70 flex items-center justify-center"
                      >
                        {">"}
                      </button>

                      {/* Dots */}
                      <div className="absolute bottom-3 left-0 right-0 flex items-center justify-center gap-1.5">
                        {imgs.map((_, i) => (
                          <button
                            key={i}
                            type="button"
                            aria-label={`Go to image ${i + 1}`}
                            onClick={() => goto(i)}
                            className={`h-2 w-2 rounded-full ${i === current ? "bg-yellow-400" : "bg-white/40"}`}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </div>

                {/* Text content BELOW the image for visibility */}
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{project.title}</h3>
                  <p className="text-sm text-gray-300 mb-3">{project.description}</p>
                  {project.link ? (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-3 py-2 text-sm font-medium rounded-md bg-yellow-500 text-black hover:bg-yellow-600"
                    >
                      Visit Project
                    </a>
                  ) : null}
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
