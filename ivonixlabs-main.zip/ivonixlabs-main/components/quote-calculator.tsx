"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Calculator, DollarSign, Clock, Layers } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface QuoteCalculatorProps {
  isOpen: boolean
  onClose: () => void
}

export default function QuoteCalculator({ isOpen, onClose }: QuoteCalculatorProps) {
  const [formData, setFormData] = useState({
    volume: "",
    material: "PLA",
    quantity: "1",
    infill: "20",
    layerHeight: "0.2",
    supportMaterial: false,
    postProcessing: false,
    rushDelivery: false,
  })

  const [quote, setQuote] = useState({
    materialCost: 0,
    laborCost: 0,
    additionalCosts: 0,
    totalCost: 0,
    estimatedTime: "",
  })

  // Pricing configuration
  const materialPrices = {
    PLA: 0.2,
    PETG: 0.3,
    ABS: 0.35,
    TPU: 0.45,
  }

  const calculateQuote = () => {
    const volume = Number.parseFloat(formData.volume) || 0
    const quantity = Number.parseInt(formData.quantity) || 1
    const infillPercent = Number.parseInt(formData.infill) || 20

    // Base material cost calculation
    const materialMultiplier = materialPrices[formData.material as keyof typeof materialPrices] || 0.2
    const infillMultiplier = 0.5 + (infillPercent / 100) * 0.5 // 50% base + infill percentage
    const materialCost = volume * materialMultiplier * infillMultiplier * quantity

    // Labor cost (base rate per hour)
    const baseTimeHours = Math.max(1, volume * 0.1 * quantity) // Rough estimate
    const layerHeightMultiplier = formData.layerHeight === "0.1" ? 1.5 : formData.layerHeight === "0.3" ? 0.8 : 1
    const estimatedHours = baseTimeHours * layerHeightMultiplier
    const laborCost = estimatedHours * 15 // $15/hour labor rate

    // Additional costs
    let additionalCosts = 0
    if (formData.supportMaterial) additionalCosts += volume * 0.05 * quantity
    if (formData.postProcessing) additionalCosts += 10 * quantity
    if (formData.rushDelivery) additionalCosts += (materialCost + laborCost) * 0.5

    const totalCost = materialCost + laborCost + additionalCosts

    // Estimated time
    const days = Math.ceil(estimatedHours / 8)
    const estimatedTime = formData.rushDelivery
      ? `${Math.max(1, Math.ceil(days / 2))} day${Math.ceil(days / 2) > 1 ? "s" : ""} (Rush)`
      : `${days} day${days > 1 ? "s" : ""}`

    setQuote({
      materialCost: Math.round(materialCost * 100) / 100,
      laborCost: Math.round(laborCost * 100) / 100,
      additionalCosts: Math.round(additionalCosts * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      estimatedTime,
    })
  }

  useEffect(() => {
    calculateQuote()
  }, [formData])

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-black border border-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex justify-between items-center p-6 border-b border-gray-800">
              <h2 className="text-2xl font-bold flex items-center">
                <Calculator className="w-6 h-6 mr-2 text-yellow-500" />
                3D Printing Quote Calculator
              </h2>
              <button onClick={onClose} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-6 p-6">
              {/* Input Form */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-blue-400">Model Specifications</h3>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Volume (cm³)</label>
                      <Input
                        type="number"
                        step="0.1"
                        value={formData.volume}
                        onChange={(e) => handleInputChange("volume", e.target.value)}
                        placeholder="Enter model volume"
                        className="bg-gray-900/50 border-gray-700"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Material</label>
                      <select
                        value={formData.material}
                        onChange={(e) => handleInputChange("material", e.target.value)}
                        className="w-full px-3 py-2 bg-gray-900/50 border border-gray-700 rounded-md text-white"
                      >
                        <option value="PLA">PLA - $0.20/cm³ (Standard)</option>
                        <option value="PETG">PETG - $0.30/cm³ (Durable)</option>
                        <option value="ABS">ABS - $0.35/cm³ (Strong)</option>
                        <option value="TPU">TPU - $0.45/cm³ (Flexible)</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Quantity</label>
                        <Input
                          type="number"
                          min="1"
                          value={formData.quantity}
                          onChange={(e) => handleInputChange("quantity", e.target.value)}
                          className="bg-gray-900/50 border-gray-700"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Infill (%)</label>
                        <select
                          value={formData.infill}
                          onChange={(e) => handleInputChange("infill", e.target.value)}
                          className="w-full px-3 py-2 bg-gray-900/50 border border-gray-700 rounded-md text-white"
                        >
                          <option value="10">10% (Light)</option>
                          <option value="20">20% (Standard)</option>
                          <option value="50">50% (Strong)</option>
                          <option value="100">100% (Solid)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Layer Height (mm)</label>
                      <select
                        value={formData.layerHeight}
                        onChange={(e) => handleInputChange("layerHeight", e.target.value)}
                        className="w-full px-3 py-2 bg-gray-900/50 border border-gray-700 rounded-md text-white"
                      >
                        <option value="0.1">0.1mm (High Detail)</option>
                        <option value="0.2">0.2mm (Standard)</option>
                        <option value="0.3">0.3mm (Fast)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4 text-green-400">Additional Services</h3>

                  <div className="space-y-3">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.supportMaterial}
                        onChange={(e) => handleInputChange("supportMaterial", e.target.checked)}
                        className="mr-3 rounded border-gray-700 bg-gray-900"
                      />
                      <span>Support Material Removal (+$0.05/cm³)</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.postProcessing}
                        onChange={(e) => handleInputChange("postProcessing", e.target.checked)}
                        className="mr-3 rounded border-gray-700 bg-gray-900"
                      />
                      <span>Post-Processing (Sanding, Painting) (+$10)</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.rushDelivery}
                        onChange={(e) => handleInputChange("rushDelivery", e.target.checked)}
                        className="mr-3 rounded border-gray-700 bg-gray-900"
                      />
                      <span>Rush Delivery (+50% total cost)</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Quote Display */}
              <div className="bg-gray-900/30 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4 text-yellow-400 flex items-center">
                  <DollarSign className="w-5 h-5 mr-2" />
                  Price Breakdown
                </h3>

                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b border-gray-700">
                    <span className="flex items-center">
                      <Layers className="w-4 h-4 mr-2 text-blue-400" />
                      Material Cost
                    </span>
                    <span className="font-semibold">${quote.materialCost.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-gray-700">
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-2 text-green-400" />
                      Labor Cost
                    </span>
                    <span className="font-semibold">${quote.laborCost.toFixed(2)}</span>
                  </div>

                  {quote.additionalCosts > 0 && (
                    <div className="flex justify-between items-center py-2 border-b border-gray-700">
                      <span>Additional Services</span>
                      <span className="font-semibold">${quote.additionalCosts.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center py-3 text-xl font-bold text-yellow-400 border-t-2 border-yellow-400">
                    <span>Total Cost</span>
                    <span>${quote.totalCost.toFixed(2)}</span>
                  </div>

                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Clock className="w-4 h-4 mr-2 text-blue-400" />
                      <span className="font-semibold">Estimated Delivery</span>
                    </div>
                    <span className="text-lg text-blue-400">{quote.estimatedTime}</span>
                  </div>

                  <div className="space-y-2 pt-4">
                    <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                      Request This Quote
                    </Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      Save Quote
                    </Button>
                  </div>

                  <div className="text-xs text-gray-400 pt-2">
                    * Prices are estimates. Final quote may vary based on model complexity and specific requirements.
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
