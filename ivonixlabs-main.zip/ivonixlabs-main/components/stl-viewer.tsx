"use client"

import { useEffect, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, RotateCcw, ZoomIn, ZoomOut, Download, Info, Upload, Calculator } from "lucide-react"
import { Button } from "@/components/ui/button"

interface STLViewerProps {
  isOpen: boolean
  onClose: () => void
  file?: File | null
}

export default function STLViewer({ isOpen, onClose, file }: STLViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [modelInfo, setModelInfo] = useState({
    vertices: 0,
    faces: 0,
    volume: 0,
    boundingBox: { x: 0, y: 0, z: 0 },
    surfaceArea: 0,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (isOpen && file) {
      loadSTLFile(file)
    }
  }, [isOpen, file])

  const loadSTLFile = async (file: File) => {
    setIsLoading(true)
    setError(null)

    try {
      const arrayBuffer = await file.arrayBuffer()
      const dataView = new DataView(arrayBuffer)

      // Check if binary STL (first 80 bytes are header, then 4 bytes for triangle count)
      const triangleCount = dataView.getUint32(80, true)
      const expectedSize = 80 + 4 + triangleCount * 50

      if (arrayBuffer.byteLength === expectedSize) {
        // Binary STL
        parseSTLBinary(dataView, triangleCount)
      } else {
        // ASCII STL
        const text = new TextDecoder().decode(arrayBuffer)
        parseSTLAscii(text)
      }
    } catch (err) {
      setError("Failed to load STL file. Please check the file format.")
      console.error("STL loading error:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const parseSTLBinary = (dataView: DataView, triangleCount: number) => {
    const vertices: number[] = []
    const faces: number[] = []
    let vertexIndex = 0

    // Skip header (80 bytes) and triangle count (4 bytes)
    let offset = 84

    for (let i = 0; i < triangleCount; i++) {
      // Skip normal vector (12 bytes)
      offset += 12

      // Read 3 vertices (9 floats, 36 bytes total)
      for (let j = 0; j < 3; j++) {
        const x = dataView.getFloat32(offset, true)
        const y = dataView.getFloat32(offset + 4, true)
        const z = dataView.getFloat32(offset + 8, true)

        vertices.push(x, y, z)
        faces.push(vertexIndex++)
        offset += 12
      }

      // Skip attribute byte count (2 bytes)
      offset += 2
    }

    calculateModelInfo(vertices, faces)
    renderModel(vertices, faces)
  }

  const parseSTLAscii = (text: string) => {
    const vertices: number[] = []
    const faces: number[] = []
    let vertexIndex = 0

    const lines = text.split("\n")

    for (const line of lines) {
      const trimmed = line.trim()
      if (trimmed.startsWith("vertex")) {
        const coords = trimmed.split(/\s+/).slice(1).map(Number)
        if (coords.length === 3) {
          vertices.push(...coords)
          faces.push(vertexIndex++)
        }
      }
    }

    calculateModelInfo(vertices, faces)
    renderModel(vertices, faces)
  }

  const calculateModelInfo = (vertices: number[], faces: number[]) => {
    const vertexCount = vertices.length / 3
    const faceCount = faces.length / 3

    // Calculate bounding box
    let minX = Number.POSITIVE_INFINITY,
      maxX = Number.NEGATIVE_INFINITY
    let minY = Number.POSITIVE_INFINITY,
      maxY = Number.NEGATIVE_INFINITY
    let minZ = Number.POSITIVE_INFINITY,
      maxZ = Number.NEGATIVE_INFINITY

    for (let i = 0; i < vertices.length; i += 3) {
      const x = vertices[i]
      const y = vertices[i + 1]
      const z = vertices[i + 2]

      minX = Math.min(minX, x)
      maxX = Math.max(maxX, x)
      minY = Math.min(minY, y)
      maxY = Math.max(maxY, y)
      minZ = Math.min(minZ, z)
      maxZ = Math.max(maxZ, z)
    }

    const boundingBox = {
      x: maxX - minX,
      y: maxY - minY,
      z: maxZ - minZ,
    }

    // Rough volume calculation (bounding box volume)
    const volume = boundingBox.x * boundingBox.y * boundingBox.z

    // Rough surface area calculation
    const surfaceArea =
      2 * (boundingBox.x * boundingBox.y + boundingBox.y * boundingBox.z + boundingBox.z * boundingBox.x)

    setModelInfo({
      vertices: vertexCount,
      faces: faceCount,
      volume: Math.round(volume * 100) / 100,
      boundingBox: {
        x: Math.round(boundingBox.x * 100) / 100,
        y: Math.round(boundingBox.y * 100) / 100,
        z: Math.round(boundingBox.z * 100) / 100,
      },
      surfaceArea: Math.round(surfaceArea * 100) / 100,
    })
  }

  const renderModel = (vertices: number[], faces: number[]) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Simple wireframe rendering
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.strokeStyle = "#60a5fa"
    ctx.lineWidth = 1

    // Project 3D to 2D (simple orthographic projection)
    const scale = 200
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2

    ctx.beginPath()
    for (let i = 0; i < faces.length; i += 3) {
      const v1 = faces[i] * 3
      const v2 = faces[i + 1] * 3
      const v3 = faces[i + 2] * 3

      const x1 = centerX + vertices[v1] * scale
      const y1 = centerY - vertices[v1 + 1] * scale
      const x2 = centerX + vertices[v2] * scale
      const y2 = centerY - vertices[v2 + 1] * scale
      const x3 = centerX + vertices[v3] * scale
      const y3 = centerY - vertices[v3 + 1] * scale

      ctx.moveTo(x1, y1)
      ctx.lineTo(x2, y2)
      ctx.lineTo(x3, y3)
      ctx.lineTo(x1, y1)
    }
    ctx.stroke()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-black border border-gray-800 rounded-lg w-full max-w-4xl h-[80vh] relative overflow-hidden"
          >
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b border-gray-800">
              <h2 className="text-2xl font-bold">3D Model Viewer</h2>
              <button onClick={onClose} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>

            <div className="flex h-full">
              {/* 3D Viewer */}
              <div className="flex-1 p-4">
                <div className="bg-gray-900/50 rounded-lg h-full flex items-center justify-center relative">
                  {isLoading ? (
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
                      <p>Loading 3D model...</p>
                    </div>
                  ) : error ? (
                    <div className="text-center text-red-400">
                      <p>{error}</p>
                    </div>
                  ) : file ? (
                    <canvas ref={canvasRef} width={600} height={400} className="border border-gray-700 rounded" />
                  ) : (
                    <div className="text-center text-gray-400">
                      <Upload className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>Upload an STL file to view it here</p>
                    </div>
                  )}

                  {/* Controls */}
                  {file && !isLoading && !error && (
                    <div className="absolute bottom-4 left-4 flex gap-2">
                      <Button size="sm" variant="outline">
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <ZoomIn className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <ZoomOut className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Info Panel */}
              <div className="w-80 p-4 border-l border-gray-800 bg-gray-900/30">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <Info className="w-5 h-5 mr-2" />
                  Model Information
                </h3>

                {file && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-yellow-500 mb-2">File Details</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Name:</span>
                          <span className="text-gray-300">{file.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Size:</span>
                          <span className="text-gray-300">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-blue-500 mb-2">Geometry</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Vertices:</span>
                          <span className="text-gray-300">{modelInfo.vertices.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Faces:</span>
                          <span className="text-gray-300">{modelInfo.faces.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-green-500 mb-2">Dimensions (mm)</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Width (X):</span>
                          <span className="text-gray-300">{modelInfo.boundingBox.x}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Depth (Y):</span>
                          <span className="text-gray-300">{modelInfo.boundingBox.y}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Height (Z):</span>
                          <span className="text-gray-300">{modelInfo.boundingBox.z}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-purple-500 mb-2">Calculations</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Volume:</span>
                          <span className="text-gray-300">{modelInfo.volume} cm³</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Surface Area:</span>
                          <span className="text-gray-300">{modelInfo.surfaceArea} cm²</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-700">
                      <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black mb-2">
                        <Calculator className="w-4 h-4 mr-2" />
                        Get Quote
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Download className="w-4 h-4 mr-2" />
                        Export Report
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
