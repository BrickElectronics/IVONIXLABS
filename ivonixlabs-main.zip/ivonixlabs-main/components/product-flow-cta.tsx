"use client"

import { motion } from "framer-motion"
import { Lightbulb, ClipboardList, Wrench, Rocket } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ProductFlowCTA() {
  const steps = [
    {
      title: "Share Your Idea",
      description: "Tell us about your vision and goals. We help clarify requirements and define success criteria.",
      icon: Lightbulb,
      accent: "text-yellow-400",
    },
    {
      title: "Plan the MVP",
      description: "We scope a lean, high-impact MVP: features, architecture, timeline, and cost that fit your needs.",
      icon: ClipboardList,
      accent: "text-blue-400",
    },
    {
      title: "Build Iteratively",
      description: "Rapid iterations with frequent demos. Hardware, firmware, and software progress in sync.",
      icon: Wrench,
      accent: "text-purple-400",
    },
    {
      title: "Launch & Improve",
      description: "Ship a reliable MVP, gather feedback, and plan the next milestones for growth.",
      icon: Rocket,
      accent: "text-green-400",
    },
  ]

  return (
    <section className="py-20 px-4 bg-black">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl md:text-4xl font-bold">MVP Path: From Idea to Launch</h2>
          <p className="text-gray-400 text-base md:text-lg mt-3">
            A simple, effective process to turn your idea into a working product.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {steps.map((step, idx) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, delay: idx * 0.07 }}
              className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 backdrop-blur-sm h-full"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className={`p-2 rounded-lg bg-gray-800/60`}>
                  <step.icon className={`w-5 h-5 ${step.accent}`} />
                </div>
                <span className="text-sm text-gray-400">Step {idx + 1}</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{step.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center mt-10"
        >
          <a href="https://tally.so/r/w7Ggo2" target="_blank" rel="noopener noreferrer" className="inline-block">
            <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-8 py-6 rounded-xl">
              Get Free Consultation
            </Button>
          </a>
          <p className="text-gray-400 text-sm mt-3">No cost. No obligation. Let’s map your MVP in minutes.</p>
        </motion.div>
      </div>
    </section>
  )
}
