"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AnimatedBackground from "@/components/animated-background"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Store, Printer, Cpu, ArrowUpRight } from "lucide-react"

export default function Product() {
  const products = [
    {
      title: "Robonixkart Ecom Store",
      description:
        "Browse a wide range of electronics, sensors, development boards, and more. Fast shipping and quality parts.",
      href: "https://robonixkart.com/",
      external: true as const,
      icon: Store,
      image: "/arduino-components-grid.jpg",
      cta: "Visit Store",
      badge: "Live",
    },
    {
      title: "3D Printing",
      description:
        "Upload STL files, preview your model, and get instant estimates. Professional prints in PLA, PETG, ABS, and TPU.",
      href: "/3d-printing",
      external: false as const,
      icon: Printer,
      image: "/3d-printing-service-hero-printer.jpg",
      cta: "Explore 3D Printing",
      badge: "Popular",
    },
    {
      title: "AI Help",
      description:
        "Describe your project and get AI-powered component recommendations with direct add-to-cart for Robonixkart.",
      href: "/ai-help",
      external: false as const,
      icon: Cpu,
      image: "/ai-electronics-assistant-components.jpg",
      cta: "Try AI Helper",
      badge: "New",
    },
  ]

  return (
    <div className="min-h-screen bg-black">
      <AnimatedBackground />
      <Navbar />
      <main className="container mx-auto px-4 py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-6xl mx-auto text-center"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Products</h1>
          <p className="text-lg md:text-xl text-gray-400 mb-10">
            Explore our offerings across hardware, services, and AI tooling.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-6xl mx-auto">
          {products.map((item, idx) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.07 }}
            >
              <Card className="bg-gray-900 border-gray-800 overflow-hidden h-full flex flex-col">
                <div className="relative aspect-[16/9]">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover"
                    priority={idx < 2}
                  />
                  <div className="absolute top-3 left-3 text-xs px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">
                    {item.badge}
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-yellow-500" />
                    <CardTitle className="text-xl">{item.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <p className="text-gray-400 mb-4">{item.description}</p>
                  {item.external ? (
                    <a href={item.href} target="_blank" rel="noopener noreferrer" className="inline-block w-full">
                      <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                        {item.cta}
                        <ArrowUpRight className="w-4 h-4 ml-2" />
                      </Button>
                    </a>
                  ) : (
                    <Link href={item.href} className="inline-block w-full">
                      <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                        {item.cta}
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {/* Coming Soon card spanning full width on large screens */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="md:col-span-2"
          >
            <Card className="bg-gradient-to-r from-gray-900 to-gray-800 border-gray-800 overflow-hidden">
              <CardContent className="p-6 md:p-8 text-center">
                <h2 className="text-2xl md:text-3xl font-semibold mb-2">More exciting products coming soon!</h2>
                <p className="text-gray-400 max-w-3xl mx-auto mb-4">
                  We&apos;re building new tools and hardware to supercharge your projects. Stay tuned for updates.
                </p>
                <div className="inline-flex items-center gap-2 text-yellow-400 text-sm md:text-base">
                  <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
                  Sneak peeks and early access announcements soon
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
