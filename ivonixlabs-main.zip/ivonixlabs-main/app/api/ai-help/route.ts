import { type NextRequest, NextResponse } from "next/server"
import Groq from "groq-sdk"

interface Component {
  id: string
  name: string
  sku: string
}

interface ProjectStep {
  stepNumber: number
  title: string
  description: string
  components?: string[]
}

interface AIResponse {
  explanation: string
  components: Component[]
  projectSteps: ProjectStep[]
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  estimatedTime: string
}

// Fallback components that always work
const FALLBACK_COMPONENTS: Component[] = [
  { id: "4214", sku: "ARD-UNO-R3", name: "Arduino Uno R3 Development Board" },
  { id: "4215", sku: "ESP32-DEV", name: "ESP32 Development Board WiFi Bluetooth" },
  { id: "4216", sku: "RPI4-4GB", name: "Raspberry Pi 4 Model B 4GB RAM" },
  { id: "4217", sku: "HC-SR04", name: "Ultrasonic Distance Sensor HC-SR04" },
  { id: "4218", sku: "SG90", name: "Servo Motor SG90 9g Micro" },
  { id: "4219", sku: "WS2812B", name: "WS2812B LED Strip Addressable RGB" },
  { id: "4220", sku: "DHT22", name: "DHT22 Temperature Humidity Sensor" },
  { id: "4221", sku: "REL-4CH", name: "4 Channel Relay Module 5V" },
  { id: "4222", sku: "BB-830", name: "Breadboard 830 Points Half Size" },
  { id: "4223", sku: "JW-MM", name: "Jumper Wires Male to Male 40pcs" },
  { id: "4224", sku: "RES-KIT", name: "Resistor Kit 1/4W Assorted Values" },
  { id: "4225", sku: "CAP-KIT", name: "Capacitor Kit Electrolytic Assorted" },
  { id: "4226", sku: "LCD-16x2", name: "LCD Display 16x2 Character Blue" },
  { id: "4227", sku: "PIR-HC", name: "PIR Motion Sensor HC-SR501" },
  { id: "4228", sku: "BUZ-5V", name: "Active Buzzer 5V Electronic" },
  { id: "4229", sku: "POT-10K", name: "Potentiometer 10K Linear Rotary" },
  { id: "4230", sku: "LED-5MM", name: "LED 5mm Assorted Colors Pack" },
  { id: "4231", sku: "SWITCH-PUSH", name: "Push Button Switch 6x6mm" },
  { id: "4232", sku: "MQ2-GAS", name: "MQ2 Gas Smoke Sensor Module" },
  { id: "4233", sku: "FLAME-SENSOR", name: "Flame Sensor Module Infrared Detection" },
  { id: "4234", sku: "NODEMCU-ESP8266", name: "NodeMCU ESP8266 WiFi Development Board" },
  { id: "4235", sku: "MOTOR-DC-12V", name: "DC Motor 12V High Torque" },
  { id: "4236", sku: "BATTERY-9V", name: "9V Battery Alkaline Long Life" },
  { id: "4237", sku: "POWER-SUPPLY-5V", name: "Power Supply Adapter 5V 2A" },
  { id: "4238", sku: "GYRO-MPU6050", name: "MPU6050 Gyroscope Accelerometer Module" }
]

// Initialize Groq client with error handling
let groq: Groq | null = null
try {
  if (process.env.GROQ_API_KEY) {
    groq = new Groq({
      apiKey: process.env.GROQ_API_KEY,
    })
    console.log("✅ Groq client initialized successfully")
  } else {
    console.log("⚠️ GROQ_API_KEY not found in environment variables")
  }
} catch (error) {
  console.error("❌ Failed to initialize Groq client:", error)
}

// Cache for component data
let componentCache: Component[] | null = null
let cacheTimestamp = 0
const CACHE_DURATION = 60 * 60 * 1000 // 1 hour

async function loadComponentData(): Promise<Component[]> {
  const now = Date.now()

  // Return cached data if it's still fresh
  if (componentCache && now - cacheTimestamp < CACHE_DURATION) {
    console.log(`📦 Using cached components (${componentCache.length} items)`)
    return componentCache
  }

  console.log("🔄 Loading component data from CSV...")

  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 8000) // 8 second timeout

    const response = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/use-BddCcGpQjI4uIeom7Vol9eUskyAG8M.csv",
      {
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; RobonixKart/1.0)",
        },
        signal: controller.signal,
      }
    )

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`CSV fetch failed with status: ${response.status}`)
    }

    const csvText = await response.text()
    console.log(`📄 CSV loaded, size: ${csvText.length} characters`)

    const lines = csvText.split("\n")
    const components: Component[] = []

    // Skip header row
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim()
      if (line) {
        try {
          // Parse CSV line (handle quoted fields better)
          const columns = []
          let current = ""
          let inQuotes = false
          
          for (let j = 0; j < line.length; j++) {
            const char = line[j]
            if (char === '"') {
              inQuotes = !inQuotes
            } else if (char === ',' && !inQuotes) {
              columns.push(current.trim())
              current = ""
            } else {
              current += char
            }
          }
          columns.push(current.trim()) // Add the last column

          if (columns.length >= 3) {
            const id = columns[0].replace(/^"|"$/g, "").trim()
            const sku = columns[1].replace(/^"|"$/g, "").trim()
            const name = columns[2].replace(/^"|"$/g, "").trim()

            if (id && name && sku) {
              components.push({ id, sku, name })
            }
          }
        } catch (parseError) {
          // Skip malformed lines
          continue
        }
      }
    }

    console.log(`✅ Successfully parsed ${components.length} components from CSV`)

    // Update cache
    componentCache = components.length > 0 ? components : FALLBACK_COMPONENTS
    cacheTimestamp = now

    return componentCache
  } catch (error) {
    console.error("❌ Error loading CSV data:", error)
    console.log("🔄 Using fallback components...")
    
    // Cache fallback components
    componentCache = FALLBACK_COMPONENTS
    cacheTimestamp = now
    
    return FALLBACK_COMPONENTS
  }
}

function findRelevantComponents(query: string, components: Component[], aiRecommendations: string[] = []): Component[] {
  console.log(`🔍 Searching components for query: "${query.substring(0, 50)}..."`)
  
  const queryLower = query.toLowerCase()
  const keywords = queryLower.split(/\s+/).filter(word => word.length > 2)
  
  // Combine AI recommendations with query-based search
  const allSearchTerms = [...keywords, ...aiRecommendations.map(r => r.toLowerCase())]

  const scored = components.map((component) => {
    const nameLower = component.name.toLowerCase()
    const skuLower = component.sku.toLowerCase()
    let score = 0

    // Higher weight for AI recommendations
    aiRecommendations.forEach((recommendation) => {
      const recLower = recommendation.toLowerCase()
      if (nameLower.includes(recLower) || skuLower.includes(recLower)) {
        score += 20
      }
    })

    // Exact phrase match gets high score
    if (nameLower.includes(queryLower)) {
      score += 15
    }

    // SKU match
    if (skuLower.includes(queryLower)) {
      score += 10
    }

    // Individual keyword matches
    keywords.forEach((term) => {
      if (nameLower.includes(term)) {
        score += 3
      }
      if (skuLower.includes(term)) {
        score += 2
      }
    })

    // Electronics terms bonus
    const electronicsTerms = [
      "sensor", "module", "arduino", "raspberry", "motor", "servo", "led", "display", "wifi",
      "bluetooth", "temperature", "humidity", "pressure", "ultrasonic", "relay", "transistor",
      "resistor", "capacitor", "diode", "microcontroller", "esp32", "esp8266", "nodemcu",
      "pir", "gyro", "accelerometer", "breadboard", "jumper", "wire", "buzzer", "potentiometer",
      "lcd", "oled", "camera", "speaker", "microphone", "battery", "power", "supply", "voltage",
      "smoke", "gas", "flame", "motion", "proximity", "fire", "detection", "alarm", "smart"
    ]

    electronicsTerms.forEach((term) => {
      if (queryLower.includes(term) && (nameLower.includes(term) || skuLower.includes(term))) {
        score += 4
      }
    })

    return { component, score }
  })

  const results = scored
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 12)
    .map((item) => item.component)

  console.log(`📊 Found ${results.length} relevant components`)
  return results
}

async function getAIResponse(query: string, components: Component[]): Promise<AIResponse> {
  if (!groq) {
    throw new Error("Groq client not initialized - check GROQ_API_KEY")
  }

  console.log("🤖 Calling Groq AI...")
  
  const componentList = components.slice(0, 50).map(c => `${c.name} (SKU: ${c.sku})`).join(", ")
  
  const prompt = `You are an expert electronics engineer. Analyze this project request and respond with ONLY valid JSON.

Project: "${query}"

Available Components: ${componentList}

Response format (JSON only, no other text):
{
  "explanation": "Comprehensive project explanation (150-250 words)",
  "difficulty": "Beginner",
  "estimatedTime": "2-3 hours",
  "projectSteps": [
    {
      "stepNumber": 1,
      "title": "Step Title",
      "description": "Detailed step description",
      "components": ["component1", "component2"]
    }
  ],
  "recommendedComponents": ["Arduino Uno", "ESP32", "DHT22"]
}

Guidelines:
- Provide 5-8 practical steps
- Use exact component names from the available list
- Set realistic difficulty and time estimates
- Include safety considerations
- No text outside the JSON structure`

  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: "You are an electronics expert. Respond only with valid JSON, no other text."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      model: "llama-3.1-70b-versatile",
      temperature: 0.2,
      max_tokens: 2500,
    })

    const aiResponseText = completion.choices[0]?.message?.content
    if (!aiResponseText) {
      throw new Error("Empty response from Groq AI")
    }

    console.log("🔄 Parsing AI response...")

    // Clean and extract JSON
    let cleanedResponse = aiResponseText.trim()
    cleanedResponse = cleanedResponse.replace(/```json\s*/g, '').replace(/```\s*$/g, '')
    
    const jsonMatch = cleanedResponse.match(/\{[\s\S]*\}/)
    if (!jsonMatch) {
      throw new Error("No JSON structure found in AI response")
    }

    const aiData = JSON.parse(jsonMatch[0])
    console.log("✅ AI response parsed successfully")

    // Find relevant components
    const relevantComponents = findRelevantComponents(
      query,
      components,
      aiData.recommendedComponents || []
    )

    return {
      explanation: aiData.explanation || "Project analysis completed with component recommendations.",
      components: relevantComponents,
      projectSteps: Array.isArray(aiData.projectSteps) ? aiData.projectSteps : [],
      difficulty: aiData.difficulty || "Intermediate",
      estimatedTime: aiData.estimatedTime || "1-2 days",
    }
  } catch (error) {
    console.error("❌ AI processing failed:", error)
    throw error
  }
}

function createFallbackResponse(query: string, components: Component[]): AIResponse {
  console.log("🆘 Creating fallback response...")
  
  const fallbackComponents = findRelevantComponents(query, components, [])
  const queryLower = query.toLowerCase()
  
  // Analyze query for smart project characteristics
  const hasSmartHome = queryLower.includes('smart') || queryLower.includes('home') || queryLower.includes('automation')
  const hasSensor = queryLower.includes('sensor') || queryLower.includes('detect') || queryLower.includes('monitor')
  const hasAlert = queryLower.includes('alert') || queryLower.includes('notification') || queryLower.includes('alarm')
  const hasWiFi = queryLower.includes('wifi') || queryLower.includes('smartphone') || queryLower.includes('internet')

  const steps = [
    {
      stepNumber: 1,
      title: "Project Planning and Requirements",
      description: "Define project specifications, create a component list, and sketch the system architecture. Consider power requirements, environmental factors, and user interface needs.",
      components: ["Paper", "Pencil", "Requirements document"]
    },
    {
      stepNumber: 2,
      title: "Component Preparation and Testing",
      description: "Gather all components and test each one individually. Verify that sensors, controllers, and actuators are working correctly before assembly.",
      components: ["Multimeter", "Test equipment", "All project components"]
    },
    {
      stepNumber: 3,
      title: "Circuit Design and Breadboard Prototype",
      description: "Create circuit diagrams and build a prototype on breadboard. Use different wire colors for power, ground, and signal connections.",
      components: ["Breadboard", "Jumper wires", "Circuit design software"]
    }
  ]

  if (hasSensor) {
    steps.push({
      stepNumber: 4,
      title: "Sensor Integration and Calibration",
      description: "Connect sensors to the microcontroller and calibrate them for accurate readings. Test sensor response under different conditions.",
      components: ["Sensors", "Calibration equipment", "Test environment"]
    })
  }

  if (hasWiFi) {
    steps.push({
      stepNumber: steps.length + 1,
      title: "Network Setup and Connectivity",
      description: "Configure WiFi connection, set up network protocols, and establish communication with external services or mobile apps.",
      components: ["WiFi module", "Router", "Network configuration tools"]
    })
  }

  steps.push({
    stepNumber: steps.length + 1,
    title: "Programming and Logic Implementation",
    description: "Write the main program code, implement control algorithms, and add error handling. Test all functions systematically.",
    components: ["Programming environment", "USB cable", "Computer"]
  })

  if (hasAlert) {
    steps.push({
      stepNumber: steps.length + 1,
      title: "Alert System Testing",
      description: "Implement and test notification systems including buzzers, LEDs, or mobile notifications. Verify alert reliability.",
      components: ["Buzzer", "LEDs", "Notification service"]
    })
  }

  steps.push({
    stepNumber: steps.length + 1,
    title: "System Integration and Final Testing",
    description: "Assemble the complete system, perform comprehensive testing, and document the project. Create user manual and troubleshooting guide.",
    components: ["Final assembly", "Test protocols", "Documentation"]
  })

  const difficulty = hasSmartHome && hasWiFi ? "Advanced" : hasSensor ? "Intermediate" : "Beginner"
  const estimatedTime = difficulty === "Advanced" ? "1-2 weeks" : difficulty === "Intermediate" ? "3-5 days" : "1-2 days"

  return {
    explanation: `This ${difficulty.toLowerCase()} electronics project focuses on creating a system based on your requirements. ${hasSensor ? 'The project incorporates sensor technology for monitoring and detection capabilities. ' : ''}${hasWiFi ? 'Network connectivity enables remote monitoring and smartphone integration. ' : ''}${hasAlert ? 'An integrated alert system provides immediate notifications when conditions are met. ' : ''}The development process requires systematic planning, careful component selection, and thorough testing at each stage. Consider environmental factors, power consumption, and safety requirements throughout the build process.`,
    components: fallbackComponents,
    projectSteps: steps,
    difficulty: difficulty as "Beginner" | "Intermediate" | "Advanced",
    estimatedTime: estimatedTime,
  }
}

export async function POST(request: NextRequest) {
  console.log("🚀 AI Help API called")
  
  try {
    // Parse request body
    let body
    try {
      body = await request.json()
    } catch (parseError) {
      console.error("❌ Request body parse error:", parseError)
      return NextResponse.json(
        { error: "Invalid JSON in request body" }, 
        { status: 400 }
      )
    }

    const { query } = body
    console.log(`📝 Query received: "${query?.substring(0, 100)}..."`)

    // Validate query
    if (!query || typeof query !== "string" || query.trim().length === 0) {
      return NextResponse.json(
        { error: "Query is required and must be a non-empty string" }, 
        { status: 400 }
      )
    }

    if (query.trim().length > 2000) {
      return NextResponse.json(
        { error: "Query too long. Please limit to 2000 characters." },
        { status: 400 }
      )
    }

    // Load component data first
    console.log("📦 Loading components...")
    const components = await loadComponentData()
    console.log(`✅ Components loaded: ${components.length} items`)

    // Try AI response first
    let aiResponse: AIResponse
    try {
      if (groq && process.env.GROQ_API_KEY) {
        aiResponse = await getAIResponse(query.trim(), components)
        console.log("✅ AI response generated successfully")
      } else {
        throw new Error("Groq AI not available")
      }
    } catch (aiError) {
      console.log("⚠️ AI failed, using fallback:", aiError)
      aiResponse = createFallbackResponse(query.trim(), components)
    }

    return NextResponse.json(aiResponse)

  } catch (error) {
    console.error("❌ Critical error in AI help API:", error)
    
    // Last resort fallback
    try {
      const components = await loadComponentData()
      const emergencyResponse = createFallbackResponse(query || "electronics project", components)
      
      return NextResponse.json(emergencyResponse)
    } catch (fallbackError) {
      console.error("❌ Even fallback failed:", fallbackError)
      
      return NextResponse.json({
        error: "Service temporarily unavailable",
        explanation: "We're experiencing technical difficulties. Please try again later.",
        components: FALLBACK_COMPONENTS.slice(0, 5),
        projectSteps: [
          {
            stepNumber: 1,
            title: "Service Unavailable",
            description: "Our AI service is temporarily down. Please try again in a few minutes.",
            components: []
          }
        ],
        difficulty: "Intermediate" as const,
        estimatedTime: "Unknown"
      }, { status: 500 })
    }
  }
}
