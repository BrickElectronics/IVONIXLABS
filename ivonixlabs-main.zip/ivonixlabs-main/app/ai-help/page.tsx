"use client"

import type React from "react"
import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Loader2, Send, ShoppingCart, Lightbulb, Zap, Shield, Plus, BookOpen, CheckCircle, AlertTriangle, RefreshCw } from "lucide-react"
import { toast } from "sonner"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import AnimatedBackground from "@/components/animated-background"

interface Component {
  id: string
  name: string
  sku: string
}

interface ProjectStep {
  stepNumber: number
  title: string
  description: string
  components?: string[]
}

interface AIResponse {
  explanation: string
  components: Component[]
  projectSteps: ProjectStep[]
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  estimatedTime: string
  error?: string
}

export default function AIHelpPage() {
  const [query, setQuery] = useState("")
  const [response, setResponse] = useState<AIResponse | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [addingToCartIds, setAddingToCartIds] = useState<Set<string>>(new Set())
  const [hasError, setHasError] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return

    if (query.trim().length > 2000) {
      toast.error("Query is too long. Please limit to 2000 characters.")
      return
    }

    setIsLoading(true)
    setResponse(null)
    setHasError(false)
    
    try {
      console.log("Sending request to AI API...")
      
      const res = await fetch("/api/ai-help", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: query.trim() }),
        // Add timeout
        signal: AbortSignal.timeout(60000) // 60 second timeout
      })

      console.log("Response status:", res.status)
      
      if (!res.ok) {
        const errorText = await res.text()
        console.error("API Error:", errorText)
        throw new Error(`Server responded with status: ${res.status}`)
      }

      const data = await res.json()
      console.log("Response data received:", data)
      
      // Check if the response contains an error field
      if (data.error) {
        setHasError(true)
        toast.error("AI service issue: " + data.error)
      } else if (data.explanation?.includes("technical difficulties")) {
        setHasError(true)
        toast.warning("AI service is temporarily unavailable, showing fallback results")
      } else {
        toast.success("AI analysis complete!")
      }
      
      setResponse(data)
      
    } catch (error) {
      console.error("Error in handleSubmit:", error)
      setHasError(true)
      
      if (error instanceof Error) {
        if (error.name === 'TimeoutError') {
          toast.error("Request timed out. Please try again with a shorter query.")
        } else if (error.message.includes('Failed to fetch')) {
          toast.error("Network error. Please check your connection and try again.")
        } else {
          toast.error("Failed to get AI response: " + error.message)
        }
      } else {
        toast.error("An unexpected error occurred. Please try again.")
      }
      
      // Set a basic fallback response
      setResponse({
        explanation: "We encountered an issue processing your request. Please try again with a simpler query or check your internet connection.",
        components: [],
        projectSteps: [],
        difficulty: "Intermediate",
        estimatedTime: "Unknown",
        error: "Request failed"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddToCart = (productId: string) => {
    setAddingToCartIds((prev) => new Set(prev).add(productId))

    setTimeout(() => {
      window.open(`https://robonixkart.com/?add-to-cart=${productId}`, "_blank")
      setAddingToCartIds((prev) => {
        const newSet = new Set(prev)
        newSet.delete(productId)
        return newSet
      })
      toast.success("Item added to cart!")
    }, 500)
  }

  const handleAddAllToCart = () => {
    if (!response?.components.length) return

    setIsAddingToCart(true)

    // Warn the user about pop-up blockers
    toast.info("Opening multiple tabs - please allow pop-ups if prompted.", {
      duration: 6000,
    })

    // Open all 'add-to-cart' tabs immediately
    response.components.forEach((component, index) => {
      setTimeout(() => {
        window.open(`https://robonixkart.com/?add-to-cart=${component.id}`, "_blank")
      }, index * 100) // Stagger the opens slightly
    })

    // Wait a few seconds, then open the final cart page
    setTimeout(() => {
      window.open("https://robonixkart.com/cart-2/", "_blank")
      toast.success(`All ${response.components.length} items added to cart!`)
      setIsAddingToCart(false)
      setAddingToCartIds(new Set())
    }, 3000)
  }

  const handleRetry = () => {
    if (query.trim()) {
      handleSubmit({ preventDefault: () => {} } as React.FormEvent)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-600"
      case "Intermediate":
        return "bg-yellow-600"
      case "Advanced":
        return "bg-red-600"
      default:
        return "bg-gray-600"
    }
  }

  const exampleQueries = [
    "Fire detection system with smartphone alerts",
    "Smart home lighting with motion sensors", 
    "Weather monitoring station with display",
    "Automated plant watering system",
    "IoT security camera with notifications",
    "Voice-controlled LED strips",
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      <AnimatedBackground />
      <Navbar />

      <main className="container mx-auto px-2 sm:px-4 py-24 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="flex flex-col items-center justify-center mb-4 sm:mb-6">
            <Image
              src="/images/design-mode/Robonixkart.%20%284%29%20%281%29%281%29.png"
              alt="Robonixkart Logo"
              width={100}
              height={100}
              className="mb-3 sm:mb-4 w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28"
            />
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent px-2">
              AI Project Assistant
            </h1>
          </div>
          <p className="text-base sm:text-lg md:text-xl text-gray-300 max-w-4xl mx-auto px-4">
            Get intelligent project guidance, step-by-step instructions, and component recommendations powered by advanced AI.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-8 sm:mb-12 px-2">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-3">
              <BookOpen className="h-6 w-6 sm:h-8 sm:w-8 text-blue-500 mb-2" />
              <CardTitle className="text-white text-lg">Step-by-Step Guide</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-gray-400 text-sm sm:text-base">
                Get detailed project instructions with clear steps and component usage
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-3">
              <Zap className="h-6 w-6 sm:h-8 sm:w-8 text-yellow-500 mb-2" />
              <CardTitle className="text-white text-lg">AI-Powered Analysis</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-gray-400 text-sm sm:text-base">
                Powered by Groq AI for intelligent project planning and component matching
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-3">
              <Shield className="h-6 w-6 sm:h-8 sm:w-8 text-green-500 mb-2" />
              <CardTitle className="text-white text-lg">Direct Shopping</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-gray-400 text-sm sm:text-base">
                Add all recommended components to your cart with one click
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Query Form */}
        <Card className="bg-gray-900 border-gray-800 mb-6 sm:mb-8 mx-2">
          <CardHeader>
            <CardTitle className="text-white text-lg sm:text-xl">Describe Your Project</CardTitle>
            <CardDescription className="text-sm sm:text-base">
              Describe your project idea in detail and get comprehensive guidance with step-by-step instructions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                placeholder="e.g., I want to build a smart fire detection system that can send alerts to my smartphone when smoke is detected. It should also have a loud alarm and be able to work with my home WiFi network..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="min-h-[120px] sm:min-h-[140px] bg-gray-800 border-gray-700 text-white placeholder-gray-400 text-sm sm:text-base"
                disabled={isLoading}
                maxLength={2000}
              />
              <div className="flex justify-between items-center text-xs text-gray-400">
                <span>{query.length}/2000 characters</span>
                {query.length > 1800 && (
                  <span className="text-yellow-400">Approaching character limit</span>
                )}
              </div>
              <Button
                type="submit"
                disabled={isLoading || !query.trim()}
                className="w-full bg-blue-600 hover:bg-blue-700 text-sm sm:text-base py-2 sm:py-3"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing Project...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Get AI Project Analysis
                  </>
                )}
              </Button>
            </form>

            <div className="mt-4 sm:mt-6">
              <p className="text-xs sm:text-sm text-gray-400 mb-2 sm:mb-3">Try these example projects:</p>
              <div className="flex flex-wrap gap-1 sm:gap-2">
                {exampleQueries.map((example, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover:bg-gray-700 bg-gray-800 text-gray-300 text-xs px-2 py-1"
                    onClick={() => setQuery(example)}
                  >
                    {example}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Response */}
        {response && (
          <div className="space-y-6 mx-2">
            {/* Error/Warning Banner */}
            {hasError && (
              <Card className="bg-yellow-900/20 border-yellow-700">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-yellow-200 text-sm">
                        AI service is experiencing issues. Showing basic component recommendations.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRetry}
                      disabled={isLoading}
                      className="border-yellow-600 text-yellow-400 hover:bg-yellow-600 hover:text-white"
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Retry
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Project Overview Card */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <CardTitle className="text-white text-lg sm:text-xl">Project Analysis</CardTitle>
                  <div className="flex gap-2">
                    <Badge className={`${getDifficultyColor(response.difficulty)} text-white`}>
                      {response.difficulty}
                    </Badge>
                    <Badge variant="outline" className="text-gray-300 border-gray-600">
                      ⏱️ {response.estimatedTime}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 leading-relaxed text-sm sm:text-base">{response.explanation}</p>
              </CardContent>
            </Card>

            {/* Project Steps Card */}
            {response.projectSteps && response.projectSteps.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg sm:text-xl flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Step-by-Step Instructions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {response.projectSteps.map((step) => (
                      <div key={step.stepNumber} className="flex gap-4">
                        <div className="flex-shrink-0">
                          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            {step.stepNumber}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-1 text-sm sm:text-base">{step.title}</h4>
                          <p className="text-gray-300 text-sm sm:text-base leading-relaxed">{step.description}</p>
                          {step.components && step.components.length > 0 && (
                            <div className="mt-2">
                              <p className="text-xs text-gray-400 mb-1">Components needed:</p>
                              <div className="flex flex-wrap gap-1">
                                {step.components.map((component, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs bg-gray-800 text-gray-300">
                                    {component}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Components Card */}
            {response.components.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg sm:text-xl">Required Components</CardTitle>
                  {hasError && (
                    <p className="text-yellow-300 text-sm">
                      Basic component recommendations based on keyword matching
                    </p>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    onClick={handleAddAllToCart}
                    disabled={isAddingToCart}
                    className="bg-orange-600 hover:bg-orange-700 text-white w-full text-sm sm:text-base py-2 sm:py-3"
                  >
                    {isAddingToCart ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Opening Tabs...
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        Add All to Cart ({response.components.length} items)
                      </>
                    )}
                  </Button>

                  <div className="space-y-3 sm:space-y-4">
                    {response.components.map((component) => {
                      const isIndividualLoading = addingToCartIds.has(component.id)
                      
                      return (
                        <div
                          key={component.id}
                          className="flex flex-col gap-3 p-3 sm:p-4 bg-gray-800 rounded-lg border border-gray-700"
                        >
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-white text-sm sm:text-base break-words">{component.name}</h4>
                            <p className="text-xs sm:text-sm text-gray-400 mt-1">SKU: {component.sku} | ID: {component.id}</p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-orange-600 text-orange-400 hover:bg-orange-600 hover:text-white bg-transparent w-full text-xs sm:text-sm py-2"
                            onClick={() => handleAddToCart(component.id)}
                            disabled={isIndividualLoading || isAddingToCart}
                          >
                            {isIndividualLoading ? (
                              <>
                                <Loader2 className="mr-2 h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Plus className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                                Add to Cart
                              </>
                            )}
                          </Button>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* No Components Found */}
            {response.components.length === 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="pt-6 text-center">
                  <Lightbulb className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">
                    No specific components were found for your query. Try describing your project with more specific component names or technical terms.
                  </p>
                  <Button
                    variant="outline"
                    onClick={handleRetry}
                    disabled={isLoading}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
